This case study is based on the asynchronous leader election protocol of Itai & Rodeh [IR90].

For more information, see: http://www.prismmodelchecker.org/casestudies/asynchronous_leader.php

=====================================================================================

[IR90]
A. Itai and M. Rodeh
Symmetry Breaking in Distributed Networks
In Information and Computation, 88:60-97, 1990
