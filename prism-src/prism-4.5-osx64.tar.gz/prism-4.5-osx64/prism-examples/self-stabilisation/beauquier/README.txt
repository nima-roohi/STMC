This case study is based on Beauquier, Gradinariu and Johnen's self-stabilising algorithm [BGJ99].

For more information, see: http://www.prismmodelchecker.org/casestudies/self-stabilisation.php

=====================================================================================

[BGJ99]
J. Beauquier, M. Gradinariu and C. Johnen
Memory space requirements for self-stabilizing leader election protocols
In Proc. ACM Symposium on Principles of Distributed Computing, pp. 199-208, ACM Press, 1999
