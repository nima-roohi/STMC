/**
 * Computation threads for model checking functionality in the GUI ("Properties" tab)
 */
package userinterface.properties.computation;
