/**
 * PRISM's graphical user interface (GUI).
 */
package userinterface;
